import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Share2, Heart, MessageCircle } from "lucide-react";
import { toast } from "sonner";

export default function Social() {
  const { user } = useAuth();
  const [selectedPlatform, setSelectedPlatform] = useState<"instagram" | "tiktok" | "twitter" | "facebook" | null>(null);
  const [shareContent, setShareContent] = useState("");

  const platforms = [
    { id: "instagram", name: "Instagram", icon: "📷", color: "bg-pink-500" },
    { id: "tiktok", name: "TikTok", icon: "🎵", color: "bg-black" },
    { id: "twitter", name: "Twitter", icon: "𝕏", color: "bg-slate-900" },
    { id: "facebook", name: "Facebook", icon: "👍", color: "bg-blue-600" },
  ];

  // Share mutation
  const shareMutation = trpc.social.share.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      setSelectedPlatform(null);
      setShareContent("");
    },
    onError: (error) => {
      toast.error(error.message || "Condivisione fallita");
    },
  });

  const handleShare = (platform: "instagram" | "tiktok" | "twitter" | "facebook") => {
    const content = shareContent || `Sto esplorando Bari con BeeHunter! #BeeHunter`;
    shareMutation.mutate({
      platform,
      content,
    });
  };

  // Get leaderboard
  const { data: leaderboard = [] } = trpc.leaderboard.global.useQuery({
    timeframe: "week",
    limit: 10,
  });

  return (
    <div className="p-4 pt-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">👥 Social</h1>
        <p className="text-slate-600">Condividi e competi</p>
      </div>

      {/* Share Section */}
      <Card className="p-4 mb-6 bg-gradient-to-r from-blue-50 to-purple-50">
        <h3 className="font-bold text-slate-900 mb-3">Condividi la tua avventura</h3>

        <textarea
          placeholder="Scrivi un messaggio personalizzato... (opzionale)"
          value={shareContent}
          onChange={(e) => setShareContent(e.target.value)}
          className="w-full p-3 border border-slate-200 rounded-lg mb-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          rows={3}
        />

        <div className="grid grid-cols-4 gap-2">
          {platforms.map((platform) => (
            <button
              key={platform.id}
              onClick={() => handleShare(platform.id as any)}
              disabled={shareMutation.isPending}
              className={`p-3 rounded-lg text-white font-bold transition ${
                platform.color
              } hover:opacity-90 disabled:opacity-50`}
            >
              <div className="text-2xl mb-1">{platform.icon}</div>
              <div className="text-xs">{platform.name}</div>
            </button>
          ))}
        </div>

        <p className="text-xs text-slate-600 mt-3">
          Condividi con #BeeHunter e guadagna +25 XP!
        </p>
      </Card>

      {/* Leaderboard Section */}
      <div className="mb-6">
        <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
          <span className="text-2xl">🏆</span> Classifica Settimanale
        </h3>

        <div className="space-y-2">
          {leaderboard.length === 0 ? (
            <div className="text-center py-8 text-slate-500">Caricamento classifica...</div>
          ) : (
            leaderboard.map((entry: any, index: number) => (
              <Card
                key={entry.userId}
                className={`p-3 flex items-center justify-between ${
                  entry.userId === user?.id ? "bg-blue-50 border-2 border-blue-300" : ""
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold">
                    {index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : index + 1}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900">
                      {entry.name || `Utente ${entry.userId}`}
                    </p>
                    {entry.userId === user?.id && (
                      <p className="text-xs text-blue-600">Tu</p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-slate-900">{entry.xp || 0} XP</p>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>

      {/* Activity Feed */}
      <div className="mb-6">
        <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
          <span className="text-2xl">📱</span> Attività Recente
        </h3>

        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="p-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="font-semibold text-slate-900">Utente ha completato un check-in</p>
                  <p className="text-xs text-slate-600 mt-1">Bari Vecchia • 2 ore fa</p>
                </div>
                <span className="text-yellow-500 font-bold">+100 XP</span>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Share Modal */}
      {selectedPlatform && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end z-40">
          <div className="bg-white w-full rounded-t-3xl p-6">
            <h2 className="text-2xl font-bold mb-4">
              Condividi su {platforms.find((p) => p.id === selectedPlatform)?.name}
            </h2>

            <div className="bg-slate-50 p-4 rounded-lg mb-4">
              <p className="text-sm text-slate-600 mb-2">Anteprima messaggio:</p>
              <p className="text-slate-900">
                {shareContent || "Sto esplorando Bari con BeeHunter! #BeeHunter"}
              </p>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setSelectedPlatform(null)}
              >
                Annulla
              </Button>
              <Button
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                onClick={() => handleShare(selectedPlatform)}
                disabled={shareMutation.isPending}
              >
                {shareMutation.isPending ? "Condividendo..." : "Condividi"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
