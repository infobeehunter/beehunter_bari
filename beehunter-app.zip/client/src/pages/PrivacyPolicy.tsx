import React from "react";
import { Card } from "@/components/ui/card";

export default function PrivacyPolicy() {
  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-slate-900 mb-2">Privacy Policy</h1>
        <p className="text-slate-600">Ultimo aggiornamento: 18 Marzo 2026</p>
      </div>

      {/* Introduction */}
      <Card className="p-6 bg-blue-50 border-blue-200">
        <p className="text-slate-700">
          BeeHunter è impegnato a proteggere la tua privacy. Questa Privacy Policy spiega come
          raccogliamo, utilizziamo, divulghiamo e salvaguardiamo le tue informazioni quando utilizzi
          la nostra applicazione mobile e il nostro sito web.
        </p>
      </Card>

      {/* Sections */}
      <div className="space-y-6">
        {/* 1. Informazioni che Raccogliamo */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">1. Informazioni che Raccogliamo</h2>
          <div className="space-y-3 text-slate-700">
            <div>
              <h3 className="font-bold mb-2">Informazioni Personali</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Nome, email, numero di telefono</li>
                <li>Data di nascita (per verificare letà)</li>
                <li>Indirizzo e informazioni di localizzazione</li>
                <li>Metodi di pagamento e informazioni di fatturazione</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-2">Dati di Utilizzo</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Cronologia di navigazione e ricerca</li>
                <li>Check-in e POI visitati</li>
                <li>Interazioni con coupon e tour</li>
                <li>Statistiche XP e badge</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-2">Dati di Geolocalizzazione</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Coordinate GPS precise (con consenso)</li>
                <li>Cronologia di movimento</li>
                <li>Punti di interesse visitati</li>
              </ul>
            </div>
          </div>
        </Card>

        {/* 2. Come Utilizziamo i Tuoi Dati */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">2. Come Utilizziamo i Tuoi Dati</h2>
          <ul className="list-disc list-inside space-y-2 text-slate-700 text-sm">
            <li>Fornire e migliorare i servizi BeeHunter</li>
            <li>Processare transazioni e inviare ricevute</li>
            <li>Inviare notifiche push e comunicazioni di marketing (con consenso)</li>
            <li>Personalizzare lesperienza utente</li>
            <li>Analizzare lutilizzo e i trend (dati aggregati)</li>
            <li>Rilevare e prevenire frodi</li>
            <li>Conformarsi agli obblighi legali</li>
          </ul>
        </Card>

        {/* 3. Base Legale del Trattamento */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">3. Base Legale del Trattamento (GDPR)</h2>
          <p className="text-slate-700 text-sm mb-3">Trattiamo i tuoi dati personali sulla base di:</p>
          <ul className="list-disc list-inside space-y-2 text-slate-700 text-sm">
            <li>
              <strong>Consenso:</strong> Per marketing, notifiche push, analytics
            </li>
            <li>
              <strong>Contratto:</strong> Per fornire i servizi richiesti
            </li>
            <li>
              <strong>Obbligo legale:</strong> Per conformarsi a leggi e regolamenti
            </li>
            <li>
              <strong>Interesse legittimo:</strong> Per sicurezza e prevenzione frodi
            </li>
          </ul>
        </Card>

        {/* 4. Condivisione dei Dati */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">4. Condivisione dei Dati</h2>
          <p className="text-slate-700 text-sm mb-3">Condividiamo i tuoi dati con:</p>
          <ul className="list-disc list-inside space-y-2 text-slate-700 text-sm">
            <li>
              <strong>Partner Commerciali:</strong> Per riscatto coupon e tour
            </li>
            <li>
              <strong>Processori di Pagamento:</strong> PayPal per transazioni
            </li>
            <li>
              <strong>Provider Cloud:</strong> Per hosting e storage dati
            </li>
            <li>
              <strong>Autorità Legali:</strong> Se richiesto dalla legge
            </li>
          </ul>
          <p className="text-slate-700 text-sm mt-3">
            Non vendiamo mai i tuoi dati personali a terze parti per scopi di marketing.
          </p>
        </Card>

        {/* 5. Diritti GDPR */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">5. I Tuoi Diritti GDPR</h2>
          <p className="text-slate-700 text-sm mb-3">Hai il diritto di:</p>
          <ul className="list-disc list-inside space-y-2 text-slate-700 text-sm">
            <li>
              <strong>Accesso:</strong> Richiedere una copia dei tuoi dati
            </li>
            <li>
              <strong>Rettifica:</strong> Correggere dati inesatti
            </li>
            <li>
              <strong>Cancellazione:</strong> Richiedere leliminazione (Diritto allOblio)
            </li>
            <li>
              <strong>Portabilità:</strong> Ricevere i dati in formato leggibile
            </li>
            <li>
              <strong>Limitazione:</strong> Limitare il trattamento dei dati
            </li>
            <li>
              <strong>Opposizione:</strong> Opporsi al trattamento per scopi specifici
            </li>
          </ul>
          <p className="text-slate-700 text-sm mt-3">
            Per esercitare questi diritti, contattaci a privacy@beehunter.app
          </p>
        </Card>

        {/* 6. Sicurezza dei Dati */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">6. Sicurezza dei Dati</h2>
          <ul className="list-disc list-inside space-y-2 text-slate-700 text-sm">
            <li>Crittografia end-to-end per dati sensibili</li>
            <li>HTTPS per tutte le comunicazioni</li>
            <li>Autenticazione OAuth sicura</li>
            <li>Audit log per operazioni sensibili</li>
            <li>Backup regolari e disaster recovery</li>
            <li>Accesso limitato ai dati personali</li>
          </ul>
        </Card>

        {/* 7. Conservazione dei Dati */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">7. Conservazione dei Dati</h2>
          <ul className="list-disc list-inside space-y-2 text-slate-700 text-sm">
            <li>Dati account: Conservati fino alla cancellazione dellaccount</li>
            <li>Dati transazioni: Conservati per 7 anni (obblighi fiscali)</li>
            <li>Dati di localizzazione: Conservati per 90 giorni</li>
            <li>Log di audit: Conservati per 1 anno</li>
            <li>Dati di marketing: Conservati fino al ritiro del consenso</li>
          </ul>
        </Card>

        {/* 8. Cookie e Tracciamento */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">8. Cookie e Tracciamento</h2>
          <p className="text-slate-700 text-sm mb-3">Utilizziamo cookie e tecnologie simili per:</p>
          <ul className="list-disc list-inside space-y-2 text-slate-700 text-sm">
            <li>
              <strong>Essenziali:</strong> Sessioni e sicurezza
            </li>
            <li>
              <strong>Funzionali:</strong> Preferenze utente
            </li>
            <li>
              <strong>Analytics:</strong> Comprendere lutilizzo (con consenso)
            </li>
            <li>
              <strong>Marketing:</strong> Personalizzazione (con consenso)
            </li>
          </ul>
          <p className="text-slate-700 text-sm mt-3">
            Puoi controllare i cookie nelle impostazioni del browser.
          </p>
        </Card>

        {/* 9. Contatti e Reclami */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">9. Contatti e Reclami</h2>
          <p className="text-slate-700 text-sm mb-3">
            Per domande sulla privacy o per esercitare i tuoi diritti:
          </p>
          <div className="bg-slate-50 p-3 rounded text-sm space-y-1">
            <p>
              <strong>Email:</strong> privacy@beehunter.app
            </p>
            <p>
              <strong>Indirizzo:</strong> BeeHunter, Bari, Italia
            </p>
            <p>
              <strong>Autorità di Controllo:</strong> Garante per la Protezione dei Dati Personali
              (Italia)
            </p>
          </div>
        </Card>

        {/* 10. Modifiche */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">10. Modifiche a Questa Policy</h2>
          <p className="text-slate-700 text-sm">
            Potremmo aggiornare questa Privacy Policy di tanto in tanto. Ti notificheremo di eventuali
            modifiche significative via email o tramite un avviso prominente nellapp.
          </p>
        </Card>
      </div>

      {/* Footer */}
      <div className="text-center text-sm text-slate-600 py-6 border-t border-slate-200">
        <p>© 2026 BeeHunter. Tutti i diritti riservati.</p>
      </div>
    </div>
  );
}
