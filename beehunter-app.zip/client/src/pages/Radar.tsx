import React, { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Search } from "lucide-react";
import { toast } from "sonner";

export default function Radar() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<"Cultura" | "Natura" | "Food" | "Eventi" | "Segreto" | undefined>();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPOI, setSelectedPOI] = useState<any>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lon: number } | null>(null);

  const categories = ["Cultura", "Natura", "Food", "Eventi", "Segreto"];

  // Get POI list
  const { data: poiList = [], isLoading } = trpc.poi.list.useQuery({
    category: selectedCategory,
  });

  // Get nearby POI
  const { data: nearbyPOI = [] } = trpc.poi.nearby.useQuery(
    {
      latitude: userLocation?.lat || 41.1371,
      longitude: userLocation?.lon || 16.8755,
      radiusKm: 5,
    },
    { enabled: !!userLocation }
  );

  // Get user location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lon: position.coords.longitude,
          });
        },
        () => {
          // Default to Bari if geolocation fails
          setUserLocation({ lat: 41.1371, lon: 16.8755 });
        }
      );
    }
  }, []);

  // Check in to POI
  const checkInMutation = trpc.poi.checkIn.useMutation({
    onSuccess: (data) => {
      toast.success(`✅ ${data.poiName}! +${data.xpAwarded} XP`);
      setSelectedPOI(null);
    },
    onError: (error) => {
      toast.error(error.message || "Check-in fallito");
    },
  });

  const handleCheckIn = (poiId: number) => {
    if (!userLocation) {
      toast.error("Abilita la geolocalizzazione");
      return;
    }

    checkInMutation.mutate({
      poiId,
      latitude: userLocation.lat,
      longitude: userLocation.lon,
    });
  };

  const filteredPOI = poiList.filter((poi: any) =>
    poi.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-4 pt-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">🗺️ Radar</h1>
        <p className="text-slate-600">Scopri i luoghi di Bari</p>
      </div>

      {/* Search Bar */}
      <div className="mb-4 flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cerca un luogo..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Category Filter */}
      <div className="mb-4 flex gap-2 overflow-x-auto pb-2">
        <Button
          variant={selectedCategory === undefined ? "default" : "outline"}
          size="sm"
          onClick={() => setSelectedCategory(undefined)}
          className="whitespace-nowrap"
        >
          Tutti
        </Button>
        {categories.map((cat) => (
          <Button
            key={cat}
            variant={selectedCategory === cat ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(cat as "Cultura" | "Natura" | "Food" | "Eventi" | "Segreto")}
            className="whitespace-nowrap"
          >
            {cat}
          </Button>
        ))}
      </div>

      {/* POI List */}
      <div className="space-y-3">
        {isLoading ? (
          <div className="text-center py-8 text-slate-500">Caricamento...</div>
        ) : filteredPOI.length === 0 ? (
          <div className="text-center py-8 text-slate-500">Nessun luogo trovato</div>
        ) : (
          filteredPOI.map((poi: any) => (
            <Card
              key={poi.id}
              className="p-4 cursor-pointer hover:shadow-lg transition"
              onClick={() => setSelectedPOI(poi)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xl">
                      {poi.category === "Cultura"
                        ? "🏛️"
                        : poi.category === "Natura"
                          ? "🌿"
                          : poi.category === "Food"
                            ? "🍽️"
                            : poi.category === "Eventi"
                              ? "🎉"
                              : "🔐"}
                    </span>
                    <h3 className="font-bold text-slate-900">{poi.name}</h3>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">{poi.description}</p>
                  <div className="flex items-center gap-4 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {Math.round(
                        Math.sqrt(
                          Math.pow(poi.latitude - (userLocation?.lat || 41.1371), 2) +
                            Math.pow(poi.longitude - (userLocation?.lon || 16.8755), 2)
                        ) * 111
                      )}
                      km
                    </span>
                    <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded">+{poi.xpReward} XP</span>
                  </div>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* POI Detail Modal */}
      {selectedPOI && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end z-40">
          <div className="bg-white w-full rounded-t-3xl p-6 max-h-96 overflow-y-auto">
            <div className="flex items-center gap-3 mb-4">
              <span className="text-4xl">
                {selectedPOI.category === "Cultura"
                  ? "🏛️"
                  : selectedPOI.category === "Natura"
                    ? "🌿"
                    : selectedPOI.category === "Food"
                      ? "🍽️"
                      : selectedPOI.category === "Eventi"
                        ? "🎉"
                        : "🔐"}
              </span>
              <div>
                <h2 className="text-2xl font-bold">{selectedPOI.name}</h2>
                <p className="text-sm text-slate-600">{selectedPOI.category}</p>
              </div>
            </div>

            <p className="text-slate-700 mb-4">{selectedPOI.description}</p>

            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <p className="text-sm text-slate-600 mb-2">Ricompensa</p>
              <p className="text-3xl font-bold text-blue-600">+{selectedPOI.xpReward} XP</p>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setSelectedPOI(null)}
              >
                Chiudi
              </Button>
              <Button
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                onClick={() => handleCheckIn(selectedPOI.id)}
                disabled={checkInMutation.isPending}
              >
                {checkInMutation.isPending ? "Verifica..." : "Check-in"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
