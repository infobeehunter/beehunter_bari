import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Gift, Zap } from "lucide-react";
import { toast } from "sonner";

export default function Shop() {
  const { user } = useAuth();
  const [selectedCoupon, setSelectedCoupon] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"coupon" | "premium">("coupon");

  // Get coupons
  const { data: coupons = [], isLoading } = trpc.coupon.list.useQuery({});

  // Redeem coupon
  const redeemMutation = trpc.coupon.redeem.useMutation({
    onSuccess: () => {
      toast.success("✅ Coupon riscattato! +50 XP bonus");
      setSelectedCoupon(null);
    },
    onError: (error) => {
      toast.error(error.message || "Riscatto fallito");
    },
  });

  const handleRedeem = (couponId: number) => {
    redeemMutation.mutate({ couponId });
  };

  return (
    <div className="p-4 pt-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">🛍️ Shop</h1>
        <p className="text-slate-600">Coupon e abbonamenti</p>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-2 mb-6 border-b border-slate-200">
        <button
          onClick={() => setActiveTab("coupon")}
          className={`pb-3 px-2 font-semibold transition ${
            activeTab === "coupon"
              ? "text-blue-600 border-b-2 border-blue-600"
              : "text-slate-600"
          }`}
        >
          <Gift className="inline w-4 h-4 mr-2" />
          Coupon
        </button>
        <button
          onClick={() => setActiveTab("premium")}
          className={`pb-3 px-2 font-semibold transition ${
            activeTab === "premium"
              ? "text-blue-600 border-b-2 border-blue-600"
              : "text-slate-600"
          }`}
        >
          <Zap className="inline w-4 h-4 mr-2" />
          Premium
        </button>
      </div>

      {/* Coupon Tab */}
      {activeTab === "coupon" && (
        <div className="space-y-3">
          {isLoading ? (
            <div className="text-center py-8 text-slate-500">Caricamento...</div>
          ) : coupons.length === 0 ? (
            <div className="text-center py-8 text-slate-500">Nessun coupon disponibile</div>
          ) : (
            coupons.map((coupon: any) => (
              <Card
                key={coupon.id}
                className="p-4 cursor-pointer hover:shadow-lg transition border-2 border-slate-200"
                onClick={() => setSelectedCoupon(coupon)}
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-bold text-slate-900">{coupon.title}</h3>
                  <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-bold">
                    {coupon.discount}
                  </span>
                </div>
                <p className="text-sm text-slate-600 mb-3">{coupon.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    Scade: {new Date(coupon.expiresAt).toLocaleDateString("it-IT")}
                  </span>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    Riscatta
                  </Button>
                </div>
              </Card>
            ))
          )}
        </div>
      )}

      {/* Premium Tab */}
      {activeTab === "premium" && (
        <div className="space-y-3">
          {/* Premium Plan */}
          <Card className="p-6 border-2 border-blue-600 bg-blue-50">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-2xl font-bold text-slate-900">BeeHunter Premium</h3>
                <p className="text-slate-600">Sblocca tutte le funzionalità</p>
              </div>
              <span className="text-3xl font-bold text-blue-600">€9.99</span>
            </div>

            <ul className="space-y-2 mb-6 text-sm text-slate-700">
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span> Accesso a tutti i POI segreti
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span> Doppio XP su tutti i check-in
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span> Coupon esclusivi
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span> Supporto prioritario
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span> Badge premium esclusivo
              </li>
            </ul>

            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3">
              Sottoscrivi per €9.99/mese
            </Button>

            {user?.premiumUntil && (
              <p className="text-center text-sm text-green-600 mt-3">
                ✓ Premium attivo fino al {new Date(user.premiumUntil).toLocaleDateString("it-IT")}
              </p>
            )}
          </Card>

          {/* Features Comparison */}
          <Card className="p-4">
            <h4 className="font-bold mb-3">Confronta i piani</h4>
            <div className="text-sm space-y-2 text-slate-600">
              <div className="flex justify-between">
                <span>POI Segreti</span>
                <span className="text-slate-900 font-semibold">Premium</span>
              </div>
              <div className="flex justify-between">
                <span>Moltiplicatore XP</span>
                <span className="text-slate-900 font-semibold">2x</span>
              </div>
              <div className="flex justify-between">
                <span>Coupon esclusivi</span>
                <span className="text-slate-900 font-semibold">Illimitati</span>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Coupon Detail Modal */}
      {selectedCoupon && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end z-40">
          <div className="bg-white w-full rounded-t-3xl p-6 max-h-96 overflow-y-auto">
            <h2 className="text-2xl font-bold mb-2">{selectedCoupon.title}</h2>
            <p className="text-slate-600 mb-4">{selectedCoupon.description}</p>

            <div className="bg-red-50 p-4 rounded-lg mb-4 border-2 border-red-200">
              <p className="text-sm text-slate-600 mb-2">Sconto</p>
              <p className="text-4xl font-bold text-red-600">{selectedCoupon.discount}</p>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg mb-4">
              <p className="text-sm text-slate-600 mb-2">Codice coupon</p>
              <p className="text-lg font-mono font-bold text-slate-900 bg-white p-2 rounded border-2 border-slate-200">
                {selectedCoupon.code}
              </p>
            </div>

            <p className="text-xs text-slate-500 mb-4">
              Scade il {new Date(selectedCoupon.expiresAt).toLocaleDateString("it-IT")}
            </p>

            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setSelectedCoupon(null)}
              >
                Chiudi
              </Button>
              <Button
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                onClick={() => handleRedeem(selectedCoupon.id)}
                disabled={redeemMutation.isPending}
              >
                {redeemMutation.isPending ? "Riscattando..." : "Riscatta"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
