import React, { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart3, TrendingUp, Users, Gift, LogOut } from "lucide-react";
import { toast } from "sonner";

export default function PartnerDashboard() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<"overview" | "coupons" | "tours" | "analytics">("overview");

  if (user?.role !== "partner" && user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Accesso Negato</h1>
          <p className="text-slate-600">Questa sezione è riservata ai partner</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Partner Dashboard</h1>
            <p className="text-slate-600">Gestisci i tuoi coupon e tour</p>
          </div>
          <Button
            variant="outline"
            onClick={() => logout()}
            className="flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto flex gap-8 px-4">
          {[
            { id: "overview", label: "Panoramica", icon: "📊" },
            { id: "coupons", label: "Coupon", icon: "🎁" },
            { id: "tours", label: "Tour", icon: "🎫" },
            { id: "analytics", label: "Analytics", icon: "📈" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-4 px-2 border-b-2 font-semibold transition ${
                activeTab === tab.id
                  ? "border-blue-600 text-blue-600"
                  : "border-transparent text-slate-600 hover:text-slate-900"
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto p-4">
        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Coupon Attivi</p>
                    <p className="text-3xl font-bold text-slate-900">12</p>
                  </div>
                  <Gift className="w-8 h-8 text-blue-600" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Riscatti Totali</p>
                    <p className="text-3xl font-bold text-slate-900">248</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-green-600" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Tasso Riscatto</p>
                    <p className="text-3xl font-bold text-slate-900">34%</p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-purple-600" />
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Clienti Unici</p>
                    <p className="text-3xl font-bold text-slate-900">156</p>
                  </div>
                  <Users className="w-8 h-8 text-orange-600" />
                </div>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card className="p-6">
              <h3 className="text-lg font-bold mb-4">Attività Recente</h3>
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded">
                    <div>
                      <p className="font-semibold text-slate-900">Coupon riscattato</p>
                      <p className="text-sm text-slate-600">Sconto 20% - 2 ore fa</p>
                    </div>
                    <span className="text-green-600 font-bold">+1</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {/* Coupons Tab */}
        {activeTab === "coupons" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">I tuoi Coupon</h2>
              <Button className="bg-blue-600 hover:bg-blue-700">+ Nuovo Coupon</Button>
            </div>

            <div className="grid gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-bold text-slate-900">Sconto {20 + i * 5}%</h3>
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-bold">
                          Attivo
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 mb-3">
                        Descrizione coupon numero {i}
                      </p>
                      <div className="flex gap-4 text-xs text-slate-500">
                        <span>Riscatti: 45</span>
                        <span>Scade: 30 giorni</span>
                        <span>Codice: PROMO{i}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Modifica
                      </Button>
                      <Button variant="outline" size="sm" className="text-red-600">
                        Disattiva
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Tours Tab */}
        {activeTab === "tours" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">I tuoi Tour</h2>
              <Button className="bg-blue-600 hover:bg-blue-700">+ Nuovo Tour</Button>
            </div>

            <div className="grid gap-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-bold text-slate-900 mb-1">Tour Bari Vecchia #{i}</h3>
                      <p className="text-sm text-slate-600 mb-3">
                        Scopri i segreti della città vecchia con una guida esperta
                      </p>
                      <div className="flex gap-4 text-xs text-slate-500">
                        <span>Prezzo: €{25 + i * 5}</span>
                        <span>Durata: 2h</span>
                        <span>Prenotazioni: {15 + i * 3}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Modifica
                      </Button>
                      <Button variant="outline" size="sm" className="text-red-600">
                        Disattiva
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === "analytics" && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Analytics</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="p-6">
                <h3 className="font-bold text-slate-900 mb-4">Riscatti per Settimana</h3>
                <div className="h-64 bg-slate-50 rounded flex items-center justify-center text-slate-500">
                  Grafico riscatti (Chart.js)
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="font-bold text-slate-900 mb-4">Top Coupon</h3>
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex justify-between items-center">
                      <span className="text-slate-900">Coupon #{i}</span>
                      <div className="w-24 bg-slate-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${(i * 30) % 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-slate-600">{i * 30}%</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            <Card className="p-6">
              <h3 className="font-bold text-slate-900 mb-4">Statistiche Clienti</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-4 bg-slate-50 rounded">
                  <p className="text-sm text-slate-600 mb-1">Clienti Nuovi</p>
                  <p className="text-2xl font-bold text-slate-900">42</p>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded">
                  <p className="text-sm text-slate-600 mb-1">Clienti Ritornanti</p>
                  <p className="text-2xl font-bold text-slate-900">114</p>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded">
                  <p className="text-sm text-slate-600 mb-1">Tasso Conversione</p>
                  <p className="text-2xl font-bold text-slate-900">28%</p>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
