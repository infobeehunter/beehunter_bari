import React from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LogOut, Settings, Flame, Trophy, Award } from "lucide-react";
import { toast } from "sonner";

export default function Profile() {
  const { user, logout } = useAuth();

  // Get user profile
  const { data: profile, isLoading: profileLoading } = trpc.user.profile.useQuery();

  // Get user stats
  const { data: stats, isLoading: statsLoading } = trpc.user.stats.useQuery();

  // Get user badges
  const { data: badges = [], isLoading: badgesLoading } = trpc.badge.userBadges.useQuery();

  // Get notifications
  const { data: notifications = [] } = trpc.notification.list.useQuery();

  const handleLogout = async () => {
    await logout();
    toast.success("Logout effettuato");
  };

  if (profileLoading || statsLoading) {
    return (
      <div className="p-4 pt-6">
        <div className="text-center py-8 text-slate-500">Caricamento...</div>
      </div>
    );
  }

  return (
    <div className="p-4 pt-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">👤 Profilo</h1>
        <p className="text-slate-600">Il tuo account BeeHunter</p>
      </div>

      {/* User Info Card */}
      <Card className="p-6 mb-6 bg-gradient-to-r from-blue-500 to-purple-500 text-white">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold">{user?.name || "Utente"}</h2>
            <p className="text-blue-100">{user?.email}</p>
          </div>
          <div className="text-4xl">🐝</div>
        </div>

        {user?.premiumUntil && (
          <div className="bg-white bg-opacity-20 px-3 py-1 rounded-full inline-block text-sm font-bold">
            ⭐ Premium
          </div>
        )}
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <Card className="p-4 text-center">
          <div className="text-3xl mb-2">⭐</div>
          <p className="text-xs text-slate-600 mb-1">XP Totali</p>
          <p className="text-2xl font-bold text-blue-600">{stats?.xpTotal || 0}</p>
        </Card>

        <Card className="p-4 text-center">
          <div className="text-3xl mb-2">🔥</div>
          <p className="text-xs text-slate-600 mb-1">Streak</p>
          <p className="text-2xl font-bold text-orange-600">{user?.streakDays || 0}</p>
        </Card>

        <Card className="p-4 text-center">
          <div className="text-3xl mb-2">🏆</div>
          <p className="text-xs text-slate-600 mb-1">Badge</p>
          <p className="text-2xl font-bold text-purple-600">{badges.length || 0}</p>
        </Card>
      </div>

      {/* Activity Stats */}
      <Card className="p-4 mb-6">
        <h3 className="font-bold text-slate-900 mb-3">Statistiche</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-slate-600">Prenotazioni</span>
            <span className="font-semibold text-slate-900">{stats?.bookingCount || 0}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-600">Ultimi check-in</span>
            <span className="font-semibold text-slate-900">{stats?.xpHistory?.length || 0}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-600">Membro da</span>
            <span className="font-semibold text-slate-900">
              {user?.createdAt ? new Date(user.createdAt).toLocaleDateString("it-IT") : "—"}
            </span>
          </div>
        </div>
      </Card>

      {/* Badges Section */}
      {badges.length > 0 && (
        <Card className="p-4 mb-6">
          <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
            <Award className="w-4 h-4" />
            I tuoi Badge ({badges.length})
          </h3>
          <div className="grid grid-cols-4 gap-3">
            {badges.map((badge: any) => (
              <div key={badge.badges.id} className="text-center">
                <div className="text-3xl mb-1">{badge.badges.icon || "🏅"}</div>
                <p className="text-xs font-semibold text-slate-900 line-clamp-2">
                  {badge.badges.name}
                </p>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Notifications */}
      {notifications.length > 0 && (
        <Card className="p-4 mb-6">
          <h3 className="font-bold text-slate-900 mb-3">Notifiche Recenti</h3>
          <div className="space-y-2">
            {notifications.slice(0, 3).map((notif: any) => (
              <div key={notif.id} className="p-2 bg-slate-50 rounded text-sm">
                <p className="font-semibold text-slate-900">{notif.title}</p>
                <p className="text-xs text-slate-600">{notif.message}</p>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Settings & Actions */}
      <div className="space-y-3">
        <Button variant="outline" className="w-full justify-start">
          <Settings className="w-4 h-4 mr-2" />
          Impostazioni
        </Button>

        <Button variant="outline" className="w-full justify-start">
          <Flame className="w-4 h-4 mr-2" />
          Sfide Attive
        </Button>

        <Button
          variant="destructive"
          className="w-full justify-start"
          onClick={handleLogout}
        >
          <LogOut className="w-4 h-4 mr-2" />
          Logout
        </Button>
      </div>

      {/* Footer Info */}
      <div className="mt-6 p-4 bg-slate-50 rounded-lg text-center text-xs text-slate-600">
        <p>BeeHunter v1.0.0</p>
        <p className="mt-1">
          <a href="#" className="text-blue-600 hover:underline">
            Privacy Policy
          </a>
          {" • "}
          <a href="#" className="text-blue-600 hover:underline">
            Termini di Servizio
          </a>
        </p>
      </div>
    </div>
  );
}
