import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Users, Clock } from "lucide-react";
import { toast } from "sonner";

export default function Tour() {
  const { user } = useAuth();
  const [selectedTour, setSelectedTour] = useState<any>(null);
  const [participants, setParticipants] = useState(1);

  // Get tours list
  const { data: tours = [], isLoading } = trpc.tour.list.useQuery({});

  // Create booking
  const bookingMutation = trpc.booking.create.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      setSelectedTour(null);
      setParticipants(1);
    },
    onError: (error) => {
      toast.error(error.message || "Prenotazione fallita");
    },
  });

  const handleBooking = (tour: any) => {
    const totalPrice = parseFloat(tour.price) * participants;
    bookingMutation.mutate({
      tourId: tour.id,
      participants,
      totalPrice,
    });
  };

  return (
    <div className="p-4 pt-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">🎫 Tour</h1>
        <p className="text-slate-600">Esperienze guidate a Bari</p>
      </div>

      {/* Tours List */}
      <div className="space-y-3">
        {isLoading ? (
          <div className="text-center py-8 text-slate-500">Caricamento...</div>
        ) : tours.length === 0 ? (
          <div className="text-center py-8 text-slate-500">Nessun tour disponibile</div>
        ) : (
          tours.map((tour: any) => (
            <Card
              key={tour.id}
              className="p-4 cursor-pointer hover:shadow-lg transition"
              onClick={() => setSelectedTour(tour)}
            >
              {tour.imageUrl && (
                <img
                  src={tour.imageUrl}
                  alt={tour.title}
                  className="w-full h-40 object-cover rounded-lg mb-3"
                />
              )}
              <h3 className="font-bold text-slate-900 mb-2">{tour.title}</h3>
              <p className="text-sm text-slate-600 mb-3">{tour.description}</p>

              <div className="flex items-center gap-4 text-xs text-slate-500 mb-3">
                {tour.duration && (
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {tour.duration}h
                  </span>
                )}
                {tour.maxParticipants && (
                  <span className="flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    Max {tour.maxParticipants}
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-blue-600">€{tour.price}</span>
                <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                  Prenota
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Booking Modal */}
      {selectedTour && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end z-40">
          <div className="bg-white w-full rounded-t-3xl p-6 max-h-96 overflow-y-auto">
            <h2 className="text-2xl font-bold mb-4">{selectedTour.title}</h2>

            <p className="text-slate-700 mb-4">{selectedTour.description}</p>

            {/* Participants Selector */}
            <div className="mb-4">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Numero di partecipanti
              </label>
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setParticipants(Math.max(1, participants - 1))}
                >
                  −
                </Button>
                <span className="w-12 text-center font-bold">{participants}</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    setParticipants(
                      Math.min(selectedTour.maxParticipants || 10, participants + 1)
                    )
                  }
                >
                  +
                </Button>
              </div>
            </div>

            {/* Price Summary */}
            <div className="bg-slate-50 p-4 rounded-lg mb-4">
              <div className="flex justify-between mb-2">
                <span className="text-slate-600">Prezzo unitario</span>
                <span className="font-semibold">€{selectedTour.price}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-slate-600">Quantità</span>
                <span className="font-semibold">×{participants}</span>
              </div>
              <div className="border-t pt-2 flex justify-between">
                <span className="font-bold">Totale</span>
                <span className="text-xl font-bold text-blue-600">
                  €{(parseFloat(selectedTour.price) * participants).toFixed(2)}
                </span>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setSelectedTour(null)}
              >
                Annulla
              </Button>
              <Button
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                onClick={() => handleBooking(selectedTour)}
                disabled={bookingMutation.isPending}
              >
                {bookingMutation.isPending ? "Elaborazione..." : "Procedi al pagamento"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
