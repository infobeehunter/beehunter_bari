import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useAuth } from "./_core/hooks/useAuth";
import { Loader2 } from "lucide-react";

// Pages
import Radar from "./pages/Radar";
import Tour from "./pages/Tour";
import Shop from "./pages/Shop";
import Social from "./pages/Social";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";

// Bottom Navigation
function BottomNav({ activePage, onPageChange }: { activePage: string; onPageChange: (page: string) => void }) {
  const navItems = [
    { id: "radar", label: "RADAR", icon: "📍" },
    { id: "tour", label: "TOUR", icon: "🎫" },
    { id: "shop", label: "SHOP", icon: "🛍️" },
    { id: "social", label: "SOCIAL", icon: "👥" },
    { id: "profile", label: "IO", icon: "👤" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex h-20 z-50">
      {navItems.map((item) => (
        <button
          key={item.id}
          onClick={() => onPageChange(item.id)}
          className={`flex-1 flex flex-col items-center justify-center gap-1 transition-all ${
            activePage === item.id ? "text-blue-600" : "text-slate-400"
          }`}
        >
          <span className="text-2xl">{item.icon}</span>
          <span className="text-xs font-bold">{item.label}</span>
        </button>
      ))}
    </div>
  );
}

// Main App Router
function Router({ activePage, onPageChange }: { activePage: string; onPageChange: (page: string) => void }) {
  return (
    <div className="pb-24">
      {activePage === "radar" && <Radar />}
      {activePage === "tour" && <Tour />}
      {activePage === "shop" && <Shop />}
      {activePage === "social" && <Social />}
      {activePage === "profile" && <Profile />}
    </div>
  );
}

function AppContent() {
  const { user, loading } = useAuth();
  const [activePage, setActivePage] = React.useState("radar");

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="animate-spin w-8 h-8 text-blue-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center h-screen gap-4 px-4">
        <div className="text-4xl mb-4">🐝</div>
        <h1 className="text-3xl font-bold text-center">BeeHunter</h1>
        <p className="text-slate-600 text-center">Esplora Bari e guadagna XP!</p>
        <a
          href={`${window.location.origin}/api/oauth/callback`}
          className="mt-6 px-6 py-3 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition"
        >
          Accedi con Manus
        </a>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Router activePage={activePage} onPageChange={setActivePage} />
      <BottomNav activePage={activePage} onPageChange={setActivePage} />
    </div>
  );
}

function App() {
  const [activePage, setActivePage] = React.useState("radar");

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <div className="min-h-screen bg-slate-50">
            <Router activePage={activePage} onPageChange={setActivePage} />
            <BottomNav activePage={activePage} onPageChange={setActivePage} />
          </div>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

import React from "react";

export default App;
